finalProj
************* Student Organizer *************

by Emma Bernstein, Samuel Zhang, and Max Kong ***************** of pd 3 *****************

What does it do?

We have created a planner program that allows one to integrate their schedule into a format that both organizes tasks and limits procrastination. We have done this through adding attributes to the tasks as they are added to the list of tasks. In addition to the name of the task, we also ask for the priority of the task to better order the schedule, a projected time that will start a timer based off this and keep you from procrastinating and a due date to keep track of when you need to accomplish tasks. Bugs ---------------------------------------- Sometimes when you run the .class file the GUI doesn't display anything. Either wait a few seconds or recompile and run. The selected task on the left hand side has the wrong timer control if you add multiple tasks.

Special Compiling

The GUI works on Ubuntu systems that run java version 1.7.0_65.

How the program should work

The program creates a GUI which has three bu- ttons: create task, delete task, and start t- imer.
The user ought to be able to create a task wi- th Name, Due date, priority, and time. Prio- rity determines the position of the task wit- hin the ArrayList of tasks, which (should) display in order on the panel. This fuction however, is currently broken. Ideally, if we were able to display our task buttons, the user would click their task and then be able to choose to work on the task ( i.e. using the timer), or delete the task.

Files
