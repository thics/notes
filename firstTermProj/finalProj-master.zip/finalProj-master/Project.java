public class Project extends Task { 

/* This file will contain specific attributes to Projects such as estimated time per day*/

}
