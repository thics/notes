public class Sorting {
  
    protected ArrayList<ArrayList> hwTime = new ArrayList<ArrayList>(); //Used long as the default for time, but change as needed
    //I think we should use an ArrayList of ArrayLists so that we can sort for each individual subject

    public long FindStandardDev(int subjectIndex) {
	for (int i; i < hwTime.get
  
  /*Given an arraylist of times, either as entered by the user to estimate, or by data gathered from a "Stop" button
  this method finds the standard deviation, factoring out outliers to give users. This estimated time will then be used to 
  give the user a suggested ammount of time to input.*/
  
}
