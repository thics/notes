inport java.util.*;

public class TerminalTest {
    Scanner s = new Scanner();

    System.out.println ("Welcome to Homework Planner /n Presented to you by Emma Bernstein, Samuel Zhang, and Max Kong");
    s.nextLine();
    System.out.println ("Welcome to Homework Planner /n Presented to you by Emma Bernstein, Samuel Zhang, and Max Kong")`;